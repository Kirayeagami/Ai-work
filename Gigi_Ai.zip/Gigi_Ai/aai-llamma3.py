import assemblyai as aai
from elevenlabs.client import ElevenLabs
from elevenlabs import stream
import ollama
import constants

#assemblyai_api_key = "fef9f1c5a94d4498ab52433223fe1309"
#pelevenlabs_api_key = "sk_b4d280b07134bc9edfc7de9cfef8937d68147fecad28b917"

class AI_Assistant:
    def __init__(self) -> None:
        aai.settings.api_key = constants.assemblyai_api_key
        self.client = ElevenLabs(
            api_key=constants.elevenlabs_api_key
        )

        self.transcriber = None

        self.full_transcript =[
            {"role":"system","content":" Hello, how are you?"},
        ]

##step 2: Real-time transcription with AssemblyAI ##
    def start_transcription(self):
        if self.transcriber:
            print("Transcription is already running.")
            return

        self.transcriber = aai.RealtimeTranscriber(
            sample_rate=16_000,
            on_data=self.on_data,
            on_error=self.on_error,
            on_open=self.on_open,
            on_close=self.on_close,
        )
        self.transcriber.connect()

        microphone_stream = aai.extras.MicrophoneStream(sample_rate=16_000)
        self.transcriber.stream(microphone_stream)


    def stop_transcription(self):
        if self.transcriber:
            self.transcriber.close()
            self.transcriber=None

    def on_open(self,session_opened: aai.RealtimeSessionOpened):
        #print("Session ID:", session_opened.session_id)
        return

    def on_data(self,transcript: aai.RealtimeTranscript):
        if not transcript.text:
            return

        if isinstance(transcript, aai.RealtimeFinalTranscript):
            print(transcript.text)
            self.generate_ai_response(transcript)
        else:
            print(transcript.text, end="\r")


    def on_error(self, error: aai.RealtimeError):
        print("An error occurred:", error)
        self.reconnect_transcriber()

    def on_close(self):
        print("Transcription session closed.")
        self.reconnect_transcriber()

    def reconnect_transcriber(self):
        print("Reconnecting transcription...")
        self.stop_transcription()
        self.start_transcription()


###step 3:Pass Real-time transcription to AI model and generate response###
    def generate_ai_response(self, transcript):
        try:
            self.stop_transcription()

            self.full_transcript.append({"role": "user", "content": transcript.text})
            print(f"\nUser: {transcript.text}", end="\r\n")

            ollama_stream = ollama.chat(
                model="llama3",
                messages=self.full_transcript,
                stream=True
            )

            print("Llama 3:", end="\r\n")
            text_buffer = ""
            full_text = ""

            for chunk in ollama_stream:
                text_buffer += chunk['message']['content']
                if text_buffer.endswith('.'):
                    self.stream_audio(text_buffer)
                    full_text += text_buffer
                    text_buffer = ""

            if text_buffer:
                self.stream_audio(text_buffer)
                full_text += text_buffer

            self.full_transcript.append({"role": "assistant", "content": full_text})
            self.start_transcription()

        except Exception as e:
            print("Error in AI response generation:", e)
            self.start_transcription()  # Ensure transcription resumes
    def stream_audio(self, text):
        audio_stream = self.client.generate(
            text=text,
            model="eleven_turbo_v2",
            stream=True
        )
        stream(audio_stream)
        print(text, end="\n", flush=True)
