#import os
#assemblyai_api_key = os.getenv("fef9f1c5a94d4498ab52433223fe1309")
#elevenlabs_api_key = os.getenv("sk_b4d280b07134bc9edfc7de9cfef8937d68147fecad28b917")


#import requests

#url = "https://ai-girlfriend-voice.p.rapidapi.com/voice/uSzdvXL4Y6qlmK67czv7/preview"

#headers = {
#	"x-rapidapi-key": "f6efad9a69msh89a62e7c12aa343p1c80efjsne1b1d02c0fcf",
#	"x-rapidapi-host": "ai-girlfriend-voice.p.rapidapi.com"
#}

#response = requests.get(url, headers=headers)

#rint(response.json())


#import requests

#url = "https://ai-girlfriend-voice.p.rapidapi.com/text-to-speech/uSzdvXL4Y6qlmK67czv7/"

#payload = { "text": "Hi sexy, ever had a wild fantasy you wanted to share? Like do you want to fuck ?" }
#headers = {
#	"x-rapidapi-key": "f6efad9a69msh89a62e7c12aa343p1c80efjsne1b1d02c0fcf",
#	"x-rapidapi-host": "ai-girlfriend-voice.p.rapidapi.com",
#	"Content-Type": "application/json"
#}

#response = requests.post(url, json=payload, headers=headers)

#print(response.json())

import os
import requests
import json

# Load API keys from environment variables
assemblyai_api_key = os.getenv("fef9f1c5a94d4498ab52433223fe1309")
elevenlabs_api_key = os.getenv("sk_b4d280b07134bc9edfc7de9cfef8937d68147fecad28b917")

# Define API endpoints and headers
voice_preview_url = "https://ai-girlfriend-voice.p.rapidapi.com/voice/uSzdvXL4Y6qlmK67czv7/preview"
text_to_speech_url = "https://ai-girlfriend-voice.p.rapidapi.com/text-to-speech/uSzdvXL4Y6qlmK67czv7/"

rapidapi_key = "f6efad9a69msh89a62e7c12aa343p1c80efjsne1b1d02c0fcf"
rapidapi_host = "ai-girlfriend-voice.p.rapidapi.com"

headers = {
    "x-rapidapi-key": rapidapi_key,
    "x-rapidapi-host": rapidapi_host
}

def get_voice_preview():
    response = requests.get(voice_preview_url, headers=headers)
    return response.json()

def text_to_speech(text):
    payload = {"text": text}
    response = requests.post(text_to_speech_url, json=payload, headers=headers)
    return response.json()

# Example usage
if __name__ == "__main__":
    voice_preview = get_voice_preview()
    print(json.dumps(voice_preview, indent=4))

    text = "Hi sexy, ever had a wild fantasy you wanted to share? Like do you want to fuck ?"
    speech_response = text_to_speech(text)
    print(json.dumps(speech_response, indent=4))